# This script generate 'content_Sa' file from manually collected data (eo_comp.txt).
#

$ perl eotable2mat.pl eo_comp.txt > content_Sa

